<?php
// This file was auto-generated from sdk-root/src/data/migrationhub-config/2019-06-30/paginators-1.json
return [ 'pagination' => [ 'DescribeHomeRegionControls' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
