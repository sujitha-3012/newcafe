<?php
// This file was auto-generated from sdk-root/src/data/notificationscontacts/2018-05-10/paginators-1.json
return [ 'pagination' => [ 'ListEmailContacts' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'emailContacts', ], ],];
