<?php
// This file was auto-generated from sdk-root/src/data/emr-serverless/2021-07-13/paginators-1.json
return [ 'pagination' => [ 'ListApplications' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'applications', ], 'ListJobRunAttempts' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'jobRunAttempts', ], 'ListJobRuns' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'jobRuns', ], ],];
