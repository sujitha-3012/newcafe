<?php
// This file was auto-generated from sdk-root/src/data/mediastore-data/2017-09-01/paginators-1.json
return [ 'pagination' => [ 'ListItems' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
