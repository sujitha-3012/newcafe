<?php
// This file was auto-generated from sdk-root/src/data/ivs-realtime/2020-07-14/waiters-2.json
return [ 'version' => 2, 'waiters' => [],];
